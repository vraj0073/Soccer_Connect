package com.soccerconnect.player;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import com.soccerconnect.database.queries.AdminQueries;
import com.soccerconnect.database.queries.PlayerQueries;
import com.soccerconnect.models.PlayerModel;
import com.soccerconnect.models.PlayerStatsModel;

import org.junit.jupiter.api.Test;
import org.assertj.core.util.Arrays;
import org.junit.jupiter.api.BeforeEach;
import org.springframework.boot.test.context.SpringBootTest;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

@SpringBootTest
public class TestViewPlayerStats{

    PlayerQueries playerq = null;

    @BeforeEach
    void setup(){
        playerq = new PlayerQueries();
    }

    @Test
    void PlayerStats() throws SQLException {
        playerq.conn = mock(Connection.class);
        Statement stmt = mock(Statement.class);
        ResultSet resultSetMock = mock(ResultSet.class);
        when(resultSetMock.getString("player_id")).thenReturn("1");
        when(resultSetMock.getString("NOM")).thenReturn("4");
        when(resultSetMock.getString("goals")).thenReturn("4");
        when(resultSetMock.getString("assists")).thenReturn("4");
        when(resultSetMock.getString("goals_saved")).thenReturn("0");
        when(resultSetMock.getString("yellow_Card")).thenReturn("0");
        when(resultSetMock.getString("red_card")).thenReturn("0");
        when(resultSetMock.getString("MOM")).thenReturn("2");
        when(resultSetMock.next()).thenReturn(true).thenReturn(false);
        when(playerq.conn.createStatement()).thenReturn(stmt);
        when(stmt.executeQuery(anyString())).thenReturn(resultSetMock);


        ArrayList<PlayerStatsModel> expected_PlayerStats = new ArrayList<>();
        expected_PlayerStats.add(new PlayerStatsModel("1","4","4","4","0","0","0","2"));
        PlayerStatsModel actual_playerStats = playerq.getPlayerStats("1");
    

        assertEquals(expected_PlayerStats.size(), actual_playerStats);
        // for (int i = 0; i<expected_PlayerStats.size(); i++){
        //     PlayerStatsModel expected_PlayerStat = expected_PlayerStats.get(i);
        //     PlayerStatsModel actual_PlayerStat = actual_playerStats.get(i);
        //     assertEquals(expected_PlayerStat.getPlayerId(),actual_PlayerStat.getPlayerId());
        //     assertEquals(expected_PlayerStat.getNom(),actual_PlayerStat.getNom());
        //     assertEquals(expected_PlayerStat.getGoals(),actual_PlayerStat.getGoals());
        //     assertEquals(expected_PlayerStat.getAsst(),actual_PlayerStat.getAsst());
        //     assertEquals(expected_PlayerStat.getGoalsSaved(),actual_PlayerStat.getGoalsSaved());
        //     assertEquals(expected_PlayerStat.getYellowCards(),actual_PlayerStat.getYellowCards());
        //     assertEquals(expected_PlayerStat.getRedCards(),actual_PlayerStat.getRedCards());
        //     assertEquals(expected_PlayerStat.getMom(),actual_PlayerStat.getMom());
        // }
    }
    
}

